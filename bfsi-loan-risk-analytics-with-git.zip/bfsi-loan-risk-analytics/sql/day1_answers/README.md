# Day 1 Answers

Put your own SQL for each question from `questions/day1_data_profiling.md` here,
one file per question or grouped logically (your call).

Naming suggestion: `q01_row_counts.sql`, `q02_null_check.sql`, etc.
