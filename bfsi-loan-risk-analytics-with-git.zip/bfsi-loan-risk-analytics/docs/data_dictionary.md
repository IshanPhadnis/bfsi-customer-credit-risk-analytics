# Data Dictionary

## Source: bank.customers (raw) / bank.customers_clean

| Column | Description | Notes |
|---|---|---|
| Customer_ID | Unique customer identifier | |
| Age | Customer age | Bounded 18-100 in cleaning |
| Gender | Customer gender | |
| Marital_Status | Single/Married/etc | |
| Education_Level | Highest education level | |
| Employment_Status | Employed/Unemployed/Self-employed | |
| Annual_Income | Self-reported annual income | Raw |
| annual_income_capped | Income capped at 500k (tune after profiling p99) | Used for ratio calcs to avoid skew |
| Credit_Score | Bureau-style credit score | 300-850 range enforced |
| credit_score_band | Bucketed score: Excellent/Good/Fair/Poor/Very Poor | Standard bureau bands |
| Number_of_Credit_Lines | Count of open credit lines | Check variance -- may be near-constant |
| Credit_Utilization_Ratio | % of available credit in use | Key risk indicator |
| high_utilization_flag | 1 if utilization >= 0.7 | Classic lender red flag |
| Debt_To_Income_Ratio | Total debt / income | Core underwriting metric |
| high_dti_flag | 1 if DTI >= 0.5 | |
| Number_of_Late_Payments | Count of late payments | |
| Tenure_in_Years | Years as a customer | |
| Total_Transactions_Last_Year | Txn count, last year | |
| Total_Spend_Last_Year | Total spend, last year | |
| Defaulted | 1 if customer defaulted, else 0 | **Target variable** for default rate KPI |
| CLV | Customer lifetime value | Pre-computed in source |
| Total_Transactions | Total transaction count (all-time or period) | |
| Avg_Transaction_Amount | Average transaction size | |
| Max_Transaction_Amount | Largest transaction | |
| Min_Transaction_Amount | Smallest transaction | |
| Fraud_Transactions | Count/flag of fraud transactions | |
| Unique_Merchant_Categories | Distinct merchant categories used | Behavioral diversity metric |
| Unique_Transaction_Cities | Distinct cities transacted in | Behavioral/geo metric |
| spend_to_income_ratio | Total_Spend_Last_Year / Annual_Income | Proxy for exposure |

## KPI Definitions
- **Default Rate** = COUNT(Defaulted = 1) / COUNT(*)
- **Default Rate by Credit Score Band** = default rate grouped by credit_score_band
- **High Risk Concentration** = % of customers with high_utilization_flag = 1 OR high_dti_flag = 1
- **Average Credit Utilization** = AVG(Credit_Utilization_Ratio)
- **Fraud Incidence Rate** = COUNT(Fraud_Transactions > 0) / COUNT(*)
- **Customer Lifetime Value (CLV) by Segment** = AVG(CLV) grouped by demographic/risk segment
- **Spend-to-Income Ratio** = indicator of financial stress/exposure
- **Late Payment Rate** = customers with Number_of_Late_Payments > 0 / total customers
