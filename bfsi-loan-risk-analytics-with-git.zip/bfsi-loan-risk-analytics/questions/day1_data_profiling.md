# Day 1 — Data Understanding & Quality

Table: `bank.customers`

Answer each using SQL in BigQuery. For each question, record: the query you wrote, the result, and a one-line takeaway (why it matters for the analysis).

## Data Profiling & Quality Questions

1. How many total records are in the table, and how many unique customers are there? (Are they the same number, or is there duplication?)
2. Are there any NULL values in the key numeric fields — `Annual_Income`, `Credit_Score`, `Credit_Utilization_Ratio`, `Debt_To_Income_Ratio`, `Defaulted`? Which columns, if any, are affected?
3. What is the overall split of `Defaulted` (0 vs 1)? What percentage of customers defaulted?
4. What are the distinct values in `Gender`, `Marital_Status`, `Education_Level`, and `Employment_Status`? Are there any inconsistent labels, typos, or unexpected categories?
5. What is the min, max, and average of `Age`? Are there any implausible values (e.g., under 18 or over 100)?
6. What is the min, max, average, and 99th percentile of `Annual_Income`? Does the data show extreme outliers?
7. What is the min and max of `Credit_Score`? Does it fall within the standard 300–850 range, or are there invalid values outside it?
8. Does `Number_of_Credit_Lines` actually vary across the dataset, or is it constant (e.g., always 1)? If constant, what does that imply for its usefulness in analysis?
9. What is the distribution of `Credit_Utilization_Ratio` and `Debt_To_Income_Ratio` — do they fall within a sensible 0–1 (or 0–100%) range, or are there invalid values above 1 or negative?
10. How many customers have `Fraud_Transactions` greater than 0? What percentage of the total is that?
11. Is there any row where `Min_Transaction_Amount` is greater than `Max_Transaction_Amount` (a logical inconsistency worth flagging)?
12. What is the range of `Tenure_in_Years`? Are there customers with 0 tenure — and if so, does that make sense given they also have transaction history?

## Findings Log
_(fill in as you go)_

| # | Query summary | Result | Takeaway |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
