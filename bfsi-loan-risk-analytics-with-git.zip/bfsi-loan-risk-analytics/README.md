# BFSI Customer Credit Risk Analytics

End-to-end analytics project simulating a bank's credit risk and customer analytics function, built with **SQL (BigQuery)** and **Tableau**. Modeled on the kind of case-study work done at retail/consumer banks (JPMorgan, Amex, Bank of America, etc.) — credit risk KPIs, default analysis, customer segmentation, and fraud incidence.

## Approach
This project is question-driven: each day has a set of business/analytical questions (in `questions/`). Answers — the actual SQL and findings — are written independently and logged in `sql/dayN_answers/`. This mirrors how analysts actually work: starting from a business question, not a pre-built query.

## Dataset
**Credit Card User Behavior & Default Dataset** (`bank.customer` in BigQuery) — customer-level data combining:
- Demographics: age, gender, marital status, education, employment
- Credit risk indicators: credit score, utilization ratio, debt-to-income ratio, late payments, default flag
- Behavioral/transaction data: spend, transaction counts, fraud flags, CLV, merchant/city diversity

Confirmed grain: one row per customer, 10,000 total rows, 10,000 unique `Customer_ID` values (no duplication).

## Tech Stack
- **BigQuery (SQL)** — data profiling, cleaning, KPI computation, segmentation
- **Tableau** — dashboarding and visualization
- **(Phase 2) Python** — EDA and a simple risk model, once SQL/Tableau phase is done

## Project Structure
```
questions/         -- business/analytical questions, by day (no answers)
sql/
  day1_answers/     -- SQL answers + findings for Day 1
docs/               -- data dictionary, KPI definitions, insights report
dashboards/         -- Tableau workbook links/screenshots
images/             -- ER diagrams, dashboard screenshots
```

## Roadmap
| Day | Focus | Deliverable |
|---|---|---|
| 1 | Data understanding & quality | Answered profiling questions, data dictionary |
| 2 | Core BFSI risk KPIs | KPI queries + findings |
| 3 | Segmentation & behavioral analysis | Segment-level views for Tableau |
| 4 | Tableau dashboards | Published dashboards |
| 5 | Insights report, interview prep | Final insights doc, polished README |

## Key KPIs (in progress)
- Default rate (overall and by credit score band / segment)
- Credit utilization & high-utilization concentration
- Debt-to-income risk concentration
- Late payment rate
- Fraud incidence rate
- Customer Lifetime Value (CLV) by segment
- Spend-to-income ratio (exposure proxy)

## Status
🚧 Day 1 — data understanding & quality in progress
